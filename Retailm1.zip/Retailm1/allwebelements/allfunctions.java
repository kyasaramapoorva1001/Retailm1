package allwebelements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class allfunctions {
	WebDriver dr;
	WebElement wb;
	//Select s;
	Writeexcel we = new Writeexcel();
	

	public allfunctions(WebDriver dr) {
		this.dr =dr;
	}
	public void enter_txt(String xp,String data){
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	public void Click_btn(String xp){
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void launchChrome(String url){
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
	
	public String verify(String xp,String td,int r,String Sheet) {
		String s4 = dr.findElement(By.xpath(xp)).getText();
		if(td.equals(s4))
		{
			System.out.println("pass");
			we.write("Pass",r,6,"FeatureSheet");
			return "Pass";
		}
		else
		{
			System.out.println("fail");
			we.write("Fail",r,6,"FeatureSheet");
			return "Fail";
		}
	}
	


}
