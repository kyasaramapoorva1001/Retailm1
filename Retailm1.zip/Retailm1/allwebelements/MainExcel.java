package allwebelements;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MainExcel {

		public String read(int row,int col,String FeatureSheet)
		{
			String s= null;
			File f = new File("C:\\Users\\IBM\\Desktop\\1tesecasesset1.xlsx");
			FileInputStream fis;
			try {
				fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet(FeatureSheet);
				XSSFRow r = sh.getRow(row);
				XSSFCell c = r.getCell(col);
				s= c.getStringCellValue();
			} 
			catch (Exception e) 
			{
 				e.printStackTrace();
			}
			
			return s;
			
		}
	
}
