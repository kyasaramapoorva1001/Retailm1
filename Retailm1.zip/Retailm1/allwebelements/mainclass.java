package allwebelements;

import org.openqa.selenium.WebDriver;

public class mainclass {

	public static void main(String[] args) {
		{
				
				String feature = null,tc = null,flag = null;
				WebDriver dr = null;
				MainExcel me = new  MainExcel();
				ReadEx re = new ReadEx();
				
				
				MainExcel ex = new MainExcel();
				for(int i=1;i<=5;i++)
				{
					feature =me.read(i, 0, "SelectionSheet");
					tc = me.read(i, 1,"SelectionSheet");
					flag =me.read(i, 2,"SelectionSheet");
					//String Nos = me.read(i, 3,"SelectionSheet");
					System.out.println(flag);
					if(flag.equals("Y"))
					{
						//System.out.println(flag);
						re.Keyworddriven(feature,tc,flag,i);
					}
					
				}
		}


	}

}
