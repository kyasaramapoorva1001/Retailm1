package allwebelements;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.WebDriver;

public class ReadEx 

{

	public void Keyworddriven(String feature,String tc,String flag,int row)
	{
		System.out.println(tc);
		String tcid = null,tsid = null,kw = null,loc=null,td=null;
		WebDriver dr = null;
		MainExcel m = new  MainExcel();
		Writeexcel wi = new Writeexcel();
		allfunctions a = new allfunctions(dr);
		System.out.println("sheet");
		for(int r=1;r<=18;r++)
		{
		//System.out.println("insideloop");
			tcid = m.read(r, 0, "FeatureSheet");
			tsid = m.read(r, 1, "FeatureSheet");
			kw = m.read(r, 3,"FeatureSheet");
			loc = m.read(r, 4,"FeatureSheet");
			td = m.read(r, 5,"FeatureSheet");
			
			if(tcid.equals(tc))
			{
				switch(kw)
				{
				case "launchChrome" :
					System.out.println("launchchrome");
					a.launchChrome(td);
					break;
				case "enter_txt" :
					a.enter_txt(loc,td);
					break;
				case "Click_btn" :
					a.Click_btn(loc);
					break;

				case "verify" :
					String res = a.verify(loc,td,r, "FeatureSheet");
					wi.write(res, row, 4,"SelectionSheet");
					break;
					

				}
			}
		
		
		}
	}
}