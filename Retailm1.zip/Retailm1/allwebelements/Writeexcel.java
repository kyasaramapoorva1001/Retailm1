package allwebelements;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Writeexcel {
	
	public void write(String Result,int r,int c,String FeatureSheet)
	{
		try {
			File f1 = new File("C:\\Users\\IBM\\Desktop\\1tesecasesset1.xlsx");
			FileInputStream fis1 = new FileInputStream(f1);
			XSSFWorkbook wb1 = new XSSFWorkbook(fis1);
			XSSFSheet sh1 = wb1.getSheet(FeatureSheet);
			
			FileOutputStream fos1 = new FileOutputStream(f1);
			XSSFRow r1 = sh1.getRow(r);
			XSSFCell c1 = r1.createCell(c);
			c1.setCellValue(Result);
			
			wb1.write(fos1);
			
			
		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
