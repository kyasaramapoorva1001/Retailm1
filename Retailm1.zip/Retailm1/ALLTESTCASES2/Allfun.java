package ALLTESTCASES2;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import allwebelements.Writeexcel;

public class Allfun {
	
	private static final String WebElement = null;
	WebDriver dr;
	WebElement wb;
	//Select s;
	writeexcel2 we = new writeexcel2();
	

	public Allfun (WebDriver dr) {

		this.dr =dr;
	}
	public void enter_text(String xp, String data)
	{
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	public void click_btn(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	public void launchchrome(String url)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}

	public void popup()
	{
		dr.switchTo().alert().accept();
		
	}
	public String verify_result(String xp,String td,int r,String Sheet) {
		String s4 = dr.findElement(By.xpath(xp)).getText();
		if(td.equals(s4))
		{
			System.out.println("pass");
			we.write("Pass",r,6,"FeatureSheet");
			return "Pass";
		}
		else
		{
			System.out.println("fail");
			we.write("Fail",r,6,"FeatureSheet");
			return "Fail";
		}
		
//	public String verify_result(String xp,String td,int r,String sheet)
//	{
//		String s = dr.findElement(By.xpath(xp)).getText();
//		System.out.println(s);
//		if(td.equalsIgnoreCase(s))
//		{
//			System.out.println("apoorva");
//			we.write("Pass",r,6,"FeatureSheet");
//			return "Pass";
//		}
//		else
//		{
//			we.write("Fail",r,6,"FeatureSheet");
//			return "Fail";
//		}
	}
		public void radio_btn(String xp)
		{
			List rb= (List)dr.findElements(By.xpath(xp));
			((WebElement)rb.get(0)).click();
			
		}
		public void clear(String xp)
		{
			dr.findElement(By.xpath(xp)).clear();
			
		}
//		public void close() 
//		{
//			dr.close();			
//		}
//	


}
