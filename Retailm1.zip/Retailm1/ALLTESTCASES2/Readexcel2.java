package ALLTESTCASES2;

import org.openqa.selenium.WebDriver;

public class Readexcel2 {
	
	public void KeywordDri(String feature,String tc,String flag,int row)
	{
		System.out.println(tc);
		String tcid = null,tsid = null,kw = null,loc=null,td=null;
		WebDriver dr = null;
		MainExcel2 m = new  MainExcel2();
		writeexcel2 wi = new writeexcel2();
		Allfun a = new Allfun(dr);
		for(int r=1;r<=57;r++)
		{
			tcid = m.read(r, 0, "FeatureSheet");
			tsid = m.read(r, 1, "FeatureSheet");
			kw = m.read(r, 3,"FeatureSheet");
			loc = m.read(r, 4,"FeatureSheet");
			td = m.read(r, 5,"FeatureSheet");
			
			if(tcid.equals(tc))
			{
				switch(kw)
				{
				case "launchchrome" :
					a.launchchrome(td);
					break;
					
				case "enter_text" :
					a.enter_text(loc,td);
					break;
					
					
				case "click_btn" :
					a.click_btn(loc);
					break;
				
				case "radio_btn":
					a.radio_btn(loc);
					break;
					
				case "popup_window" :
					a.popup();
					break;
					
				case "verify_result" :
					String res = a.verify_result(loc,td,r, "FeatureSheet");
					wi.write(res, row, 4,"SelectionSheet");
					break;
//				case "verify_result" :
//					String res = a.verify_result(loc,td,r,"FeatureSheet");
//					wi.write(res, row, 6,"FeatureSheet");
//					break;
//					
				case "clear":
					a.clear(loc);
					break;
//				case "close":
//					a.close();
//					break;

				}
			}
		
		
		
		}
	}


}
