package ALLTESTCASES2;

import org.openqa.selenium.WebDriver;

public class Mainclass2 {

	public static void main(String[] args) {
		String feature = null,tc = null,flag = null;
		WebDriver dr = null;
		MainExcel2 me = new  MainExcel2();
		Readexcel2 re = new Readexcel2();
		System.out.println("in main");
		
		
		//MainExcel ex = new MainExcel();
		for(int i=1;i<=5;i++)
		{
			//System.out.println("in main for ");
			feature =me.read(i, 0, "SelectionSheet");
			tc = me.read(i, 1,"SelectionSheet");
			flag =me.read(i, 2,"SelectionSheet");
			//Nos =me.read(i, 3,"Sheet2");
			//System.out.println(flag);
			if(flag.equals("Y"))
			{
				System.out.println(flag);
				re.KeywordDri(feature,tc,flag,i);
			}
		
		}
	
}


	}


